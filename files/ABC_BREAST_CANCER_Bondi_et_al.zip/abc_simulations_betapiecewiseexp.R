rm(list=ls())

library(haven)
library(doSNOW)
#library(doParallel)


set.seed(1347)   # NEVER TOUCH THIS!!
extraterms <- sample(1:77839,(1.05*77839-77839),replace=TRUE)


#####################    OBSERVED SUMMARY STATISTICS     #######################
################  WE DON'T NEED THIS PART IN THE SIMULATIONS
# (1) proportion of cases in the sample
# (2) proportion of symptomatic diagnoses among the observed diagnoses
# (3) age at asymptomatic diagnosis
# (4) age at symptomatic diagnosis

obs.data<-read.csv("mock_data.csv")


############           COVARIATES FOR THE SIMULATED DATASETS      ############
covariates <- obs.data[,5:8]
covariates <- rbind(covariates, covariates[extraterms,])

library(foreach)
library(doParallel)
#library(abc)

#setup parallel backend to use many processors
cores=detectCores()
cl <- makeCluster(cores[1]) 

registerDoSNOW(cl)



k = 200000 # NUMBER OF SIMULATIONS
n= dim(covariates)[1]  # ASSUMPTION: THE DISTRIBUTION OF THE COVARIATES AT ENTRY IS THE SAME
# FOR WOMEN WHO ENTERED AND THOSE WHO HAVE T_S < ENTRY. SO WE ASSIGN THE
# 78052 COVARIATE VECTORS TO THE FIRST 78052 WOMEN IN THE SIMULATED SAMPLE,
# PLUS WE TAKE A RANDOM SAMPLE OF THE COVARIATE VECTORS FOR THE REMAINING
# 81305-78052 WOMEN. THIS INTRODUCES A SLIGHT BIAS, BUT WE EXPECT THIS
# TO WORK FAIRLY WELL.


finalMatrix <- foreach(iter=1:k,.combine=rbind) %dopar% {
#.errorhandling='pass' ,.combine=rbind) %dopar% {
    #print(s)
	print(iter)
  
#####   CHANGE THIS PART TO CHANGE MODEL   #####  
    # SAMPLE FROM THE PRIOR DISTRIBUTIONS
    beta0 <- rnorm(n=1, 0.65, 0.1) # intercept
    beta1 <- rnorm(n=1, 0, 0.05)   # children
    beta2 <- rnorm(n=1, 0, 0.05)   # edu
    beta3 <- rnorm(n=1, 0, 0.05)   # family history
    mu <- beta0+beta1*covariates[,1]+beta2*covariates[,2]+beta3*covariates[,3]
    sigma <- runif(n=1, min=0.02, max=0.25)
    lambda <- runif(n=3, min=0.1, max=4)# MST between 3 months and 10 years
    p <- rbeta(n=1, shape1=3, shape2=21) # mean=0.125
    p0 <- log(p/(1-p))              # intercept
    p1 <- runif(n=1, min=-2, max=2) # children
    p2 <- runif(n=1, min=-2, max=2) # edu
    p3 <- runif(n=1, min=-2, max=2) # family history
    p <- exp(p0+p1*covariates[,1]+p2*covariates[,2]+p3*covariates[,3])/
      (1+exp(p0+p1*covariates[,1]+p2*covariates[,2]+p3*covariates[,3]))
    proposal <- c(beta0, beta1, beta2, beta3, sigma, lambda, p0, p1, p2, p3)
    #print(proposal)
    # GENERATE DISEASE HISTORIES FROM THE PRIOR MODEL
    print(proposal)
    alpha <- ((1-mu)/(sigma^2)-1/mu)*mu^2	
    ta <- 100*rbeta(n, shape1=alpha, shape2=alpha*(1/mu-1))
	  if ((min(mu)<0)|(max(mu)>1)|(min(mu*(1-mu))<sigma^2)) ta <- rep(30,n)  # an extreme value for extreme parameter values
    print(summary(ta))
    which.bin <- cut(ta, breaks=c(-Inf,55,65,Inf), labels=1:3) # 2 cutpoints for TA: 55 and 65 years
    delta <- NA
    for (i in 1:3) {
       if (sum(which.bin==i)>0) delta[which.bin==i] <- rexp(sum(which.bin==i),lambda[i])
    }
#####    END OF CHANGES HERE    #####   
    
    ts <- ta + delta
    diseased <- rbinom(n, 1, prob=p)
    
    # SCREENING STRATEGY ANS CENSORING
    first.exam <- pmin(rnorm(n, mean=60, sd=7.5),88)
    stopping.year <- first.exam + pmin(pmax(rnorm(n, mean=15, sd=4.9), 0),88-first.exam)
    invitations <- data.frame(first.exam)
    frequency.years <- runif(n, 1.8, 2.2)
    numb.inv <- floor((stopping.year-first.exam)/frequency.years)
    #summary(apply(!is.na(invitations),1,sum))
    ncol <- max(numb.inv)
    
    for(i in 2:ncol) {
      invitations[[i]] <- ifelse(numb.inv<i,NA,invitations[[i-1]]+ frequency.years + runif(n,-0.5,0.5))
    }
    head(invitations)
    prop.attendance <- 0.6
    attendance <- matrix(rbinom(ncol(invitations)*n,1,prop.attendance), ncol=ncol(invitations))
    invitations[attendance==0] <- NA
    # FIX BY LAURA 5jun2020
    first_attended_exam <- apply(invitations, 1, min, na.rm=T)
    # 60.9 is the mean of the first attended exam for the non-missing values
    # I substitute the Inf values with a normal with that mean
    first_attended_exam[first_attended_exam==Inf] <- rnorm(n=sum(first_attended_exam==Inf),mean=60.9,sd=5)
    #  subsample <- which(ts<first_attended_exam & diseased==1) # ENTRY REQUIREMENT
    # END FIX BY LAURA 5jun2020
    subsample <- which(ts>first_attended_exam | diseased==0) # INCLUSION REQUIREMENT
    # END FIX BY LAURA 5jun2020
    adm.censoring.initial <- apply(cbind(apply(invitations, 1, max, na.rm=T),first_attended_exam),1,max, na.rm=T)
    id.subsample <- (1:n)[subsample]
    n.new <- length(id.subsample)
    ta <- ta[id.subsample]
    ts <- ts[id.subsample]
    diseased <- diseased[id.subsample]
    invitations <- invitations[id.subsample,]
    attendance <- attendance[id.subsample,]
    cens.initial <- first_attended_exam[id.subsample]+1
    cens.final <- first_attended_exam[id.subsample]+ 201
    censoring.other.causes <- runif(n.new, cens.initial, cens.final)
    adm.censoring.initial <- adm.censoring.initial[id.subsample] 
    adm.censoring.final <-  adm.censoring.initial+1
    adm.censoring <- runif(n.new,adm.censoring.initial, adm.censoring.final)
    censoring <- apply(cbind(adm.censoring, censoring.other.causes),1,min)
    only.diseased <- which(diseased==1)
    indicator.symp <- rep(NA, n.new)
    exam <- rep(NA, n.new)
    last.negative <- rep(NA, n.new)
    # last.negative[(1:n.new)[-only.diseased]] <- sapply((1:n.new)[-only.diseased], function(i) 
    # max(invitations[i,][invitations[i,]<censoring[i]], na.rm=T), simplify = TRUE)
    observed <- censoring
    for (i in only.diseased) { 
      if (all(is.na(invitations[i,]))) {#if the women did not attend any examination
        last.negative[i] <- -Inf
        exam[i] <- ts[i]
        indicator.symp[i] <- 1}
      else if (all(invitations[i,]<ta[i], na.rm=TRUE))  {
        # the condition means that the asymptomatic detectability state is after the last screening examination
        last.negative[i] <- max(invitations[i,], na.rm=T) 
        exam[i] <- ts[i]
        indicator.symp[i] <- 1
      } else {# it means that there is an examination after the beginning of the asymptomatic detectability state
        # f is the date of the first mammogram after ta
        f <- invitations[i,which(invitations[i,]>ta[i])[1]]
        l <- which(invitations[i,]>ta[i])[1]
        if (ts[i]>f) {# symptomatic detectability is after the exam
          indicator.symp[i] <- 0 
          exam[i] <- f 
          # there should be some checks if there is an exam before this one - otherwise put value 0
          if (any(invitations[i,1:l]<f, na.rm=TRUE)) last.negative[i] <- 
            max(invitations[i,which(invitations[i,]<f)]) else last.negative[i] <- 0
        } else { # this else is for the condition "ts[i]>f"
          indicator.symp[i] <- 1
          exam[i] <- ts[i]
          if (any(invitations[i,1:l]<f, na.rm=TRUE)) last.negative[i] <- 
            max(invitations[i,which(invitations[i,]<f)]) else last.negative[i] <- 0
        }
      } 
    } # for for loop
    # for the cases without any attendance 
    
    observed[only.diseased] <- apply(cbind(exam[only.diseased], censoring[only.diseased]),1,function(x) min(x,na.rm = T))
    indicator.event <- (observed < censoring)
    indicator.symp[indicator.event==F] <- NA
    
    sim.data <- cbind(indicator.event, indicator.symp, observed, last.negative, 
                      first.exam = first_attended_exam[id.subsample],covariates[id.subsample,])
    # for summary stats (1) and (2)
    prop_diag_sim <- tapply(sim.data$indicator.event, sim.data$group, mean)
    prop_symp_diag_sim <- tapply(sim.data$indicator.symp, sim.data$group, mean, na.rm=T)
    # ASYMPTOMATIC DIAGNOSES (3)
    sim.data$age_asymp_sim <- NA
    sim.data$age_asymp_sim[sim.data$indicator.symp==0 & !is.na(sim.data$indicator.symp)] <- sim.data$observed[sim.data$indicator.symp==0 & !is.na(sim.data$indicator.symp)]
    median_sim_asymp <- tapply(sim.data$age_asymp_sim, sim.data$group, median, na.rm=T) # observed summaries
    # SYMPTOMATIC DIAGNOSES (4)
    sim.data$age_symp_sim <- NA
    sim.data$age_symp_sim[sim.data$indicator.symp==1 & !is.na(sim.data$indicator.symp)] <- sim.data$observed[sim.data$indicator.symp==1 & !is.na(sim.data$indicator.symp)]
    median_sim_symp <- tapply(sim.data$age_symp_sim, sim.data$group, median, na.rm=T) # observed summaries
    summaries <- c(prop_diag_sim ,prop_symp_diag_sim, median_sim_asymp, median_sim_symp)
    #print(c(proposal, summaries))
    finalMatrix <- c(as.numeric(proposal), as.numeric(summaries))
    finalMatrix
  }
save(finalMatrix, file=paste("Output-Beta-piecewiseExp-",k,"-",n,".Rdata",sep=""), compress = F)


stopCluster(cl)



# ################################################################################
# ####                         ANALYSIS ABC OUTPUT                           #####
# ################################################################################


load(paste("Output-Beta-piecewiseExp-",k,"-",n,".Rdata",sep=""))
results <- finalMatrix

k=dim(results)[1] # number of simulations
head(results)
colnames(results) <- c("beta0", "beta1", "beta2", "beta3", "sigma", "lambda1", "lambda2", "lambda3",
                       "p0", "p1", "p2", "p3","s11","s12","s13","s14","s15","s16","s17",
                       "s18","s21","s22","s23","s24","s25","s26","s27","s28","s31","s32",
                       "s33","s34","s35","s36","s37","s38","s41","s42","s43","s44","s45",
                       "s46","s47","s48")
# sij = summary statistic i in covariate group j (i=1,..,4 and j=1,...,8)
summary(results) # NAs when there are no (symptomatic) diagnoses


#####################    OBSERVED SUMMARY STATISTICS     #######################
# (1) proportion of cases in the sample
# (2) proportion of symptomatic diagnoses among the observed diagnoses
# (3) age at asymptomatic diagnosis
# (4) age at symptomatic diagnosis

mock_data<-read.csv("mock_data.csv")
summaries <- function(obs.data) {
  table(obs.data$group)
  # for summary stats (1) and (2)
  prop_diag <- tapply(obs.data$indicator.event, obs.data$group, mean)
  prop_symp_diag <- tapply(obs.data$indicator.symp, obs.data$group, mean, na.rm=T)
  # ASYMPTOMATIC DIAGNOSES (3)
  obs.data$age_asymp_obs <- NA
  obs.data$age_asymp_obs[obs.data$indicator.event==1 & obs.data$indicator.symp==0] <- obs.data$observed[obs.data$indicator.event==1 & obs.data$indicator.symp==0]
  #boxplot(obs.data$age_asymp_obs~obs.data$group)
  median_obs_asymp <- tapply(obs.data$age_asymp_obs, obs.data$group, median, na.rm=T)
  table(!is.na(obs.data$age_asymp_obs), obs.data$group) # numerosity and #diagnoses in each covariate group
  # SYMPTOMATIC DIAGNOSES (4)
  obs.data$age_symp_obs <- NA
  obs.data$age_symp_obs[obs.data$indicator.event==1 & obs.data$indicator.symp==1] <- obs.data$observed[obs.data$indicator.event==1 & obs.data$indicator.symp==1]
  #boxplot(obs.data$age_symp_obs~obs.data$group)
  median_obs_symp <- tapply(obs.data$age_symp_obs, obs.data$group, median, na.rm=T) # observed summaries
  table(!is.na(obs.data$age_symp_obs), obs.data$group) # numerosity and #diagnoses in each covariate group
  obs.summaries <- c(prop_diag, prop_symp_diag, median_obs_asymp, median_obs_symp) }###   INSERIRE SUMMARIES DEL MOCK DATASET
# vector of length 32 containing the observed summary statistics in the real (or mock) data
obs.summaries <- summaries(mock_data)


# using abc package
library(abc)

# rejection
posterior <- abc(target=obs.summaries,param=results[,1:12],sumstat=results[,13:44], tol=0.05,method="rejection")
summary(posterior)
par(mfrow=c(3,4))
hist(posterior)
# cv to choose tolerance
# cv <- cv4abc(abc.out=posterior, nval=10, param=results[,1:12],sumstat=results[,13:44], tols=c(0.001,0.005,0.01,0.05,0.1))

# local linear regression adjustment
posterior_loclin <- abc(target=obs.summaries,param=results[,1:12],sumstat=results[,13:44],
                        tol=0.5,method="loclinear")
cv <- cv4abc(abc.out=posterior_loclin, nval=20, param=results[,1:12],sumstat=results[,13:44], tols=c(0.003,0.005,0.01,0.02,0.05))
apply(summary(cv),1,sum) # choose the one with the smallest sum of (squared) CV errors
plot(cv)
posterior_loclin <- abc(target=obs.summaries,param=results[,1:12],sumstat=results[,13:44],
                        tol=0.005,method="loclinear")
summary(posterior_loclin,intvl = 0.95)
par(mfrow=c(3,4))
hist(posterior_loclin)

x <- cbind(matrix(c(0,0,0,0,0,1,0,1,0,0,1,1,1,0,0,1,0,1,1,1,0,1,1,1), byrow=T, ncol=3), seq(from=1,to=8,by=1))
post <- posterior_loclin$adj.values
#write.table(post,sep=" ",eol = "\n",file="PosteriorSamples-BetaPiecewiseExp-size1000.txt", row.names=F)


number_param <- 12

n <- dim(post)[1]
# p in the 8 groups
p <- matrix(NA, ncol=8, nrow=n)
for (i in 1:8) {
  p[,i] <- exp(post[,number_param-3]+x[i,1]*post[,number_param-2] +x[i,2]*post[,number_param-1]+x[i,3]*post[,number_param]) /(1+exp(post[,number_param-3]+x[i,1]*post[,number_param-2]+x[i,2]*post[,number_param-1]+x[i,3]*post[,number_param]))
}
summary(p)
par(mfrow=c(1,1))
boxplot(p)


# mean of T_A
mu <- matrix(NA, ncol=8, nrow=n)
for (i in 1:8) {
  mu[,i] <- (post[,1]+x[i,1]*post[,2]+x[i,2]*post[,3]+x[i,3]*post[,4])
}
summary(mu)
par(mfrow=c(1,1))
boxplot(mu, col=8, xlab="Group",ylab="Mu")


# sd of T_A
sigma<- 100*post[,5]
boxplot(sigma) # same in all groups
summary(sigma) # same in all groups
# T_A
ta <- matrix(NA, ncol=8, nrow=n)
alpha <- matrix(NA, ncol=8,nrow=n)
mu <- matrix(NA, ncol=8, nrow=n)
for (i in 1:8) {
  mu[,i] <- (post[,1]+x[i,1]*post[,2]+x[i,2]*post[,3]+x[i,3]*post[,4])
}
sigma <- post[,5]

for (i in 1:8) {
  alpha[,i] <- ((1-mu[,i])/(sigma^2)-1/mu[,i])*(mu[,i])^2	
  ta[,i] <- 100*(rbeta(n=nrow(ta), shape1=alpha[,i], shape2=alpha[,i]*(1/mu[,i]-1))) # one draw for each value of (mu,sigma)
}
boxplot(ta, col=8, xlab="Group",ylab="T_A")
#apply(ta,2,hist)
summary(ta)
# lambda
lambda <- post[,6:8]
colnames(lambda) <- c("Ta<55", "55<Ta<65","Ta>65")
par(mfrow=c(1,1))
boxplot(lambda, col=8,ylab="Lambda")
# Delta
delta <- matrix(NA, ncol=3, nrow=n)
for (i in 1:3) {
  delta[,i] <- rexp(n=nrow(delta), rate=lambda[,i])
}
colnames(delta) <- c("Ta<55", "55<Ta<65","Ta>65")
summary(delta)
par(mfrow=c(1,1))
boxplot(delta, col=8, xlab="Group",ylab="Delta",ylim=c(0,6))



par(mfrow=c(2,3))
boxplot(100*mu, col="tomato", xlab="Group",ylab=expression(mu), ylim=c(35,90))
boxplot(100*sigma, col="tomato", xlab="Same for all groups",ylab=expression(sigma), ylim=c(0,25)) # same for all groups
boxplot(ta, col="tomato", xlab="Group",ylab=expression(T[A]), ylim=c(12,100))
boxplot(lambda, col="tomato", xlab="Group",ylab="Lambda",ylim=c(-1,8))
boxplot(delta, col="tomato", xlab="Group",ylab="Delta",ylim=c(0,7.5))
boxplot(p, col="tomato", xlab="Group",ylab="p",ylim=c(0,0.47))


par(mfrow=c(1,2))
boxplot(ta, col="tomato", xlab="Group",main=expression(T[A]), ylim=c(12,100))
boxplot(delta, col="tomato", xlab="Group",main=expression(Delta),ylim=c(0,8))



# COMPARING PRIORS AND POSTERIORS
# parameters: beta0, beta1, beta2, beta3, sigma, lambda1, lambda2, lambda3, p0, p1, p2, p3

library(ggplot2)
library(MASS)
library("ggpubr")
theme_set(
  theme_bw() +
    theme(legend.position = "top",
          axis.title.x=element_blank(),
          axis.title.y=element_blank())
)
posterior_approx <- post
m <- length(posterior_approx[,1])
dat1 <- data.frame(distrib=c(rnorm(n=10000,0.65,0.10),posterior_approx[,1]),yy = rep(letters[1:2],times = c(10000,m)))
figure1 <-ggplot(dat1,aes(x=distrib)) + 
  geom_density(alpha = 0.1, data=subset(dat1,yy == 'a'), col="red",linetype = "dashed") +
  geom_histogram(data=subset(dat1,yy == 'b'),aes(y=..density..),fill = "blue", alpha = 0.2,binwidth=0.01) +
  geom_density(alpha = 0.1, data=subset(dat1,yy == 'b'), col="blue") + 
  labs(title=expression(beta[0]))
dat2 <- data.frame(distrib = c(rnorm(n=10000, mean=0, sd=0.05),posterior_approx[,2]),yy = rep(letters[1:2],times = c(10000,m)))
figure2 <- ggplot(dat2,aes(x=distrib)) + 
  geom_density(alpha = 0.1, data=subset(dat2,yy == 'a'), col="red",linetype = "dashed") + 
  geom_histogram(data=subset(dat2,yy == 'b'),aes(y=..density..),fill = "blue", alpha = 0.2,binwidth=0.01) +
  geom_density(alpha = 0.1, data=subset(dat2,yy == 'b'), col="blue") + 
  labs(title=expression(beta[1]))
dat3 <- data.frame(distrib = c(rnorm(n=10000, mean=0, sd=0.05),posterior_approx[,3]),yy = rep(letters[1:2],times = c(10000,m)))
figure3 <- ggplot(dat3,aes(x=distrib)) + 
  geom_density(alpha = 0.1, data=subset(dat3,yy == 'a'), col="red",linetype = "dashed") + 
  geom_histogram(data=subset(dat3,yy == 'b'),aes(y=..density..),fill = "blue", alpha = 0.2,binwidth=0.01) +
  geom_density(alpha = 0.1, data=subset(dat3,yy == 'b'), col="blue") + 
  labs(title=expression(beta[2]))
dat4 <- data.frame(distrib = c(rnorm(n=10000, mean=0, sd=0.05),posterior_approx[,4]),yy = rep(letters[1:2],times = c(10000,m)))
figure4 <- ggplot(dat4,aes(x=distrib)) + 
  geom_density(alpha = 0.1, data=subset(dat4,yy == 'a'), col="red",linetype = "dashed") + 
  geom_histogram(data=subset(dat4,yy == 'b'),aes(y=..density..),fill = "blue", alpha = 0.2,binwidth=0.01) +
  geom_density(alpha = 0.1, data=subset(dat4,yy == 'b'), col="blue") + 
  labs(title=expression(beta[3])) 
dat5 <- data.frame(distrib = c(runif(n=10000, min=0, max=0.25),posterior_approx[,5]),yy = rep(letters[1:2],times = c(10000,m)))
figure5 <-ggplot(dat5,aes(x=distrib)) + 
  geom_segment(aes(x = 0.02, y = 1/(0.25-0.02), xend = 0.25, yend = 1/(0.25-0.02)),linetype = "dashed", colour = "red") + 
  geom_segment(aes(x = 0.25, y = 0, xend = 0.25, yend = 1/(0.25-0.02)),linetype = "dashed", colour = "red") +
  geom_segment(aes(x = 0.02, y = 0, xend = 0.02, yend = 1/(0.25-0.02)),linetype = "dashed", colour = "red") +
  geom_histogram(data=subset(dat5,yy == 'b'),aes(y=..density..),fill = "blue", alpha = 0.2,binwidth=0.005) +
  geom_density(alpha = 0.1, data=subset(dat5,yy == 'b'), col="blue") + 
  labs(title=expression(sigma))
dat6 <- data.frame(distrib = c(runif(n=10000, min=0.1, max=4),posterior_approx[,6]),yy = rep(letters[1:2],times = c(10000,m)))
figure6 <-ggplot(dat6,aes(x=distrib)) + 
  geom_segment(aes(x = 0, y = 0.25, xend = 4, yend = 0.25),linetype = "dashed", colour = "red") + 
  geom_segment(aes(x = 4, y = 0, xend = 4, yend = 0.25),linetype = "dashed", colour = "red") +
  geom_segment(aes(x = 0, y = 0, xend = 0, yend = 0.25),linetype = "dashed", colour = "red") +
  geom_histogram(data=subset(dat6,yy == 'b'),aes(y=..density..),fill = "blue", alpha = 0.2,binwidth=0.1) +
  geom_density(alpha = 0.1, data=subset(dat6,yy == 'b'), col="blue") + 
  labs(title=expression(lambda[1]))
dat7 <- data.frame(distrib = c(runif(n=10000, min=0.1, max=4),posterior_approx[,7]),yy = rep(letters[1:2],times = c(10000,m)))
figure7 <-ggplot(dat7,aes(x=distrib)) + 
  geom_segment(aes(x = 0, y = 0.25, xend = 4, yend = 0.25),linetype = "dashed", colour = "red") + 
  geom_segment(aes(x = 4, y = 0, xend = 4, yend = 0.25),linetype = "dashed", colour = "red") +
  geom_segment(aes(x = 0, y = 0, xend = 0, yend = 0.25),linetype = "dashed", colour = "red") +
  geom_histogram(data=subset(dat7,yy == 'b'),aes(y=..density..),fill = "blue", alpha = 0.2,binwidth=0.1) +
  geom_density(alpha = 0.1, data=subset(dat7,yy == 'b'), col="blue") + 
  labs(title=expression(lambda[2]))
dat8 <- data.frame(distrib = c(runif(n=10000, min=0.1, max=4),posterior_approx[,8]),yy = rep(letters[1:2],times = c(10000,m)))
figure8 <-ggplot(dat8,aes(x=distrib)) + 
  geom_segment(aes(x = 0, y = 0.25, xend = 4, yend = 0.25),linetype = "dashed", colour = "red") + 
  geom_segment(aes(x = 4, y = 0, xend = 4, yend = 0.25),linetype = "dashed", colour = "red") +
  geom_segment(aes(x = 0, y = 0, xend = 0, yend = 0.25),linetype = "dashed", colour = "red") +
  geom_histogram(data=subset(dat8,yy == 'b'),aes(y=..density..),fill = "blue", alpha = 0.2,binwidth=0.1) +
  geom_density(alpha = 0.1, data=subset(dat8,yy == 'b'), col="blue") + 
  labs(title=expression(lambda[3]))
bet<-rbeta(n=10000, shape1=3, shape2=21)
dat9 <- data.frame(distrib = c(log(bet)/(1-bet),posterior_approx[,9]),yy = rep(letters[1:2],times = c(10000,m)))
figure9 <-ggplot(dat9,aes(x=distrib)) + 
  geom_density(alpha = 0.1, data=subset(dat9,yy == 'a'), col="red",linetype = "dashed") + 
  geom_histogram(data=subset(dat9,yy == 'b'),aes(y=..density..),fill = "blue", alpha = 0.2,binwidth=0.2) +
  geom_density(alpha = 0.1, data=subset(dat9,yy == 'b'), col="blue") + 
  labs(title=expression(p[0]))
dat10 <- data.frame(distrib = c(runif(n=10000, min=-2, max=2),posterior_approx[,10]),yy = rep(letters[1:2],times = c(10000,m)))
figure10 <-ggplot(dat10,aes(x=distrib)) + 
  geom_segment(aes(x = -2, y = 0.25, xend = 2, yend = 0.25),linetype = "dashed", colour = "red") + 
  geom_segment(aes(x = 2, y = 0, xend = 2, yend = 0.25),linetype = "dashed", colour = "red") +
  geom_segment(aes(x = -2, y = 0, xend = -2, yend = 0.25),linetype = "dashed", colour = "red") +
  geom_histogram(data=subset(dat10,yy == 'b'),aes(y=..density..),fill = "blue", alpha = 0.2,binwidth=0.2) +
  geom_density(alpha = 0.1, data=subset(dat10,yy == 'b'), col="blue") + 
  labs(title=expression(p[1]))
dat11 <- data.frame(distrib = c(runif(n=10000, min=-2, max=2),posterior_approx[,11]),yy = rep(letters[1:2],times = c(10000,m)))
figure11 <-ggplot(dat11,aes(x=distrib)) + 
  geom_segment(aes(x = -2, y = 0.25, xend = 2, yend = 0.25),linetype = "dashed", colour = "red") + 
  geom_segment(aes(x = 2, y = 0, xend = 2, yend = 0.25),linetype = "dashed", colour = "red") +
  geom_segment(aes(x = -2, y = 0, xend = -2, yend = 0.25),linetype = "dashed", colour = "red") +
  geom_histogram(data=subset(dat11,yy == 'b'),aes(y=..density..),fill = "blue", alpha = 0.2,binwidth=0.2) +
  geom_density(alpha = 0.1, data=subset(dat11,yy == 'b'), col="blue") + 
  labs(title=expression(p[2]))
dat12 <- data.frame(distrib = c(runif(n=10000, min=-2, max=2),posterior_approx[,12]),yy = rep(letters[1:2],times = c(10000,m)))
figure12 <-ggplot(dat12,aes(x=distrib)) + 
  stat_function(fun = dunif, args = list(min = -2, max = 2), col="red",linetype = "dashed") + 
  geom_segment(aes(x = 2, y = 0, xend = 2, yend = 0.25),linetype = "dashed", colour = "red") +
  geom_segment(aes(x = -2, y = 0, xend = -2, yend = 0.25),linetype = "dashed", colour = "red") +
  geom_histogram(data=subset(dat12,yy == 'b'),aes(y=..density..),fill = "blue", alpha = 0.2,binwidth=0.2) +
  geom_density(alpha = 0.1, data=subset(dat12,yy == 'b'), col="blue") + 
  labs(title=expression(p[3]))


figure <- ggarrange(figure1, figure2, figure3, figure4,figure5, figure6,figure7,figure8,
                    figure9, figure10, figure11, figure12, ncol = 3, nrow = 4,common.legend=T)

figure



#install.packages("HDInterval", dep=T, lib="C:/Program Files/R/R-4.0.5/library"))
library(HDInterval)
hdi(post, credMass = 0.95)

library(tRophicPosition)
apply(post,2,getPosteriorMode)

## 2nd way to compute Modes and Intervals
for (i in 1:12) {
  print(density(post[,i])$x[which.max(density(post[,i])$y)])
  print(round(t(hdi(post[,i], credMass = 0.95)), digits=3))
}



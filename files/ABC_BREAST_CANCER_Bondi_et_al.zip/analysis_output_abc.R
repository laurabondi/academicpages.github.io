# ################################################################################
# ###########     ANALYSIS ABC OUTPUT WITH DEPENDENCE + COVARIATES     ###########
# ################################################################################


load("Output-BetaExp-1e+05-81305.Rdata")
results1 <- finalMatrix
load("Output-BetaExp-1e+05-81305-1.Rdata")
results2 <- finalMatrix
results <- rbind(results1,results2)

k=dim(results)[1] # number of simulations
head(results)
colnames(results) <- c("beta0", "beta1", "beta2", "beta3", "sigma", "lambda1", "lambda2", "lambda3",
                       "p0", "p1", "p2", "p3","s11","s12","s13","s14","s15","s16","s17",
                       "s18","s21","s22","s23","s24","s25","s26","s27","s28","s31","s32",
                       "s33","s34","s35","s36","s37","s38","s41","s42","s43","s44","s45",
                       "s46","s47","s48")
# sij = summary statistic i in covariate group j (i=1,..,4 and j=1,...,8)
summary(results) # NAs when there are no (symptomatic) diagnoses


#####################    OBSERVED SUMMARY STATISTICS     #######################
# (1) proportion of cases in the sample
# (2) proportion of symptomatic diagnoses among the observed diagnoses
# (3) age at asymptomatic diagnosis
# (4) age at symptomatic diagnosis
# vector of length 32 containing the observed summary statistics in the real (or mock) data
mock_data<-read.csv("mock_data.csv")
summaries <- function(obs.data) {
  table(obs.data$group)
  # for summary stats (1) and (2)
  prop_diag <- tapply(obs.data$indicator.event, obs.data$group, mean)
  prop_symp_diag <- tapply(obs.data$indicator.symp, obs.data$group, mean, na.rm=T)
  # ASYMPTOMATIC DIAGNOSES (3)
  obs.data$age_asymp_obs <- NA
  obs.data$age_asymp_obs[obs.data$indicator.event==1 & obs.data$indicator.symp==0] <- obs.data$observed[obs.data$indicator.event==1 & obs.data$indicator.symp==0]
  #boxplot(obs.data$age_asymp_obs~obs.data$group)
  median_obs_asymp <- tapply(obs.data$age_asymp_obs, obs.data$group, median, na.rm=T)
  table(!is.na(obs.data$age_asymp_obs), obs.data$group) # numerosity and #diagnoses in each covariate group
  # SYMPTOMATIC DIAGNOSES (4)
  obs.data$age_symp_obs <- NA
  obs.data$age_symp_obs[obs.data$indicator.event==1 & obs.data$indicator.symp==1] <- obs.data$observed[obs.data$indicator.event==1 & obs.data$indicator.symp==1]
  #boxplot(obs.data$age_symp_obs~obs.data$group)
  median_obs_symp <- tapply(obs.data$age_symp_obs, obs.data$group, median, na.rm=T) # observed summaries
  table(!is.na(obs.data$age_symp_obs), obs.data$group) # numerosity and #diagnoses in each covariate group
  #equivalent to  median(obs.data$age_asymp_obs[obs.data$group==1],na.rm=T)
  obs.summaries <- c(prop_diag, prop_symp_diag, median_obs_asymp, median_obs_symp) }###   INSERIRE SUMMARIES DEL MOCK DATASET
obs.summaries <- summaries(mock_data)


# using abc package
library(abc)

# rejection
posterior <- abc(target=obs.summaries,param=results[,1:12],sumstat=results[,13:44], tol=0.005,method="rejection")
summary(posterior)
par(mfrow=c(3,4))
hist(posterior)
# posterior <- abc(target=stand_obs,param=results[,1:12],sumstat=stand_res, tol=0.02,method="rejection")
# # same results because of normalise function inside abc
# summary(posterior)
# cv to choose tol
# cv <- cv4abc(abc.out=posterior, nval=10, param=results[,1:12],sumstat=results[,13:44], tols=c(0.001,0.005,0.01,0.05,0.1))

# local linear regression adjustment
posterior_loclin <- abc(target=obs.summaries,param=results[,1:12],sumstat=results[,13:44],
                        tol=0.001,method="loclinear")
cv <- cv4abc(abc.out=posterior_loclin, nval=20, param=results[,1:12],sumstat=results[,13:44], tols=c(0.003,0.005,0.01,0.02,0.05))
apply(summary(cv),1,sum) # I choose 0.005 for assump2, 0.02 for assump1
plot(cv)
posterior_loclin <- abc(target=obs.summaries,param=results[,1:12],sumstat=results[,13:44],
                        tol=0.005,method="loclinear")
summary(posterior_loclin,intvl = 0.95)
par(mfrow=c(3,4))
hist(posterior_loclin)

x <- cbind(matrix(c(0,0,0,0,0,1,0,1,0,0,1,1,1,0,0,1,0,1,1,1,0,1,1,1), byrow=T, ncol=3), seq(from=1,to=8,by=1))
post <- posterior_loclin$adj.values
#write.table(post,sep=" ",eol = "\n",file="PosteriorSamples-BetaPiecewiseExp-size1000.txt", row.names=F)


number_param <- 12

n <- dim(post)[1]
# p in the 8 groups
p <- matrix(NA, ncol=8, nrow=n)
for (i in 1:8) {
  p[,i] <- exp(post[,number_param-3]+x[i,1]*post[,number_param-2] +x[i,2]*post[,number_param-1]+x[i,3]*post[,number_param]) /(1+exp(post[,number_param-3]+x[i,1]*post[,number_param-2]+x[i,2]*post[,number_param-1]+x[i,3]*post[,number_param]))
}
summary(p)
par(mfrow=c(1,1))
boxplot(p)


# mean of T_A
mu <- matrix(NA, ncol=8, nrow=n)
for (i in 1:8) {
  mu[,i] <- (post[,1]+x[i,1]*post[,2]+x[i,2]*post[,3]+x[i,3]*post[,4])
}
summary(mu)
par(mfrow=c(1,1))
boxplot(mu, col=8, xlab="Group",ylab="Mu")


# sd of T_A
sigma<- 100*post[,5]
boxplot(sigma) # same in all groups
summary(sigma) # same in all groups
# T_A
ta <- matrix(NA, ncol=8, nrow=n)
alpha <- matrix(NA, ncol=8,nrow=n)
mu <- matrix(NA, ncol=8, nrow=n)
for (i in 1:8) {
  mu[,i] <- (post[,1]+x[i,1]*post[,2]+x[i,2]*post[,3]+x[i,3]*post[,4])
}
sigma <- post[,5]

for (i in 1:8) {
  alpha[,i] <- ((1-mu[,i])/(sigma^2)-1/mu[,i])*(mu[,i])^2	
  ta[,i] <- 100*(rbeta(n=nrow(ta), shape1=alpha[,i], shape2=alpha[,i]*(1/mu[,i]-1))) # one draw for each value of (mu,sigma)
}
boxplot(ta, col=8, xlab="Group",ylab="T_A")
#apply(ta,2,hist)
summary(ta)
# lambda
lambda <- post[,6:8]
colnames(lambda) <- c("Ta<55", "55<Ta<65","Ta>65")
par(mfrow=c(1,1))
boxplot(lambda, col=8,ylab="Lambda")
# Delta
delta <- matrix(NA, ncol=3, nrow=n)
for (i in 1:3) {
  delta[,i] <- rexp(n=nrow(delta), rate=lambda[,i])
}
colnames(delta) <- c("Ta<55", "55<Ta<65","Ta>65")
summary(delta)
par(mfrow=c(1,1))
boxplot(delta, col=8, xlab="Group",ylab="Delta",ylim=c(0,6))



par(mfrow=c(2,3))
boxplot(100*mu, col="tomato", xlab="Group",ylab=expression(mu), ylim=c(35,90))
boxplot(100*sigma, col="tomato", xlab="Same for all groups",ylab=expression(sigma), ylim=c(0,25)) # same for all groups
boxplot(ta, col="tomato", xlab="Group",ylab=expression(T[A]), ylim=c(12,100))
boxplot(lambda, col="tomato", xlab="Group",ylab="Lambda",ylim=c(-1,8))
boxplot(delta, col="tomato", xlab="Group",ylab="Delta",ylim=c(0,7.5))
boxplot(p, col="tomato", xlab="Group",ylab="p",ylim=c(0,0.47))


par(mfrow=c(1,2))
boxplot(ta, col="tomato", xlab="Group",main=expression(T[A]), ylim=c(12,100))
boxplot(delta, col="tomato", xlab="Group",main=expression(Delta),ylim=c(0,8))



# COMPARING PRIORS AND POSTERIORS
# parameters: beta0, beta1, beta2, beta3, sigma, lambda1, lambda2, lambda3, p0, p1, p2, p3

library(ggplot2)
library(MASS)
library("ggpubr")
theme_set(
  theme_bw() +
    theme(legend.position = "top",
          axis.title.x=element_blank(),
          axis.title.y=element_blank())
)
posterior_approx <- post
m <- length(posterior_approx[,1])
dat1 <- data.frame(distrib=c(rnorm(n=10000,0.65,0.10),posterior_approx[,1]),yy = rep(letters[1:2],times = c(10000,m)))
figure1 <-ggplot(dat1,aes(x=distrib)) + 
  geom_density(alpha = 0.1, data=subset(dat1,yy == 'a'), col="red",linetype = "dashed") +
  geom_histogram(data=subset(dat1,yy == 'b'),aes(y=..density..),fill = "blue", alpha = 0.2,binwidth=0.01) +
  geom_density(alpha = 0.1, data=subset(dat1,yy == 'b'), col="blue") + 
  #geom_histogram(data=subset(dat1,yy == 'a'),aes(y=..density..),fill = "red", alpha = 0.2,binwidth=1) +
  labs(title=expression(beta[0]))
dat2 <- data.frame(distrib = c(rnorm(n=10000, mean=0, sd=0.05),posterior_approx[,2]),yy = rep(letters[1:2],times = c(10000,m)))
figure2 <- ggplot(dat2,aes(x=distrib)) + 
  #geom_histogram(data=subset(dat2,yy == 'a'),aes(y=..density..),fill = "red", alpha = 0.2,binwidth=1) +
  geom_density(alpha = 0.1, data=subset(dat2,yy == 'a'), col="red",linetype = "dashed") + 
  geom_histogram(data=subset(dat2,yy == 'b'),aes(y=..density..),fill = "blue", alpha = 0.2,binwidth=0.01) +
  geom_density(alpha = 0.1, data=subset(dat2,yy == 'b'), col="blue") + 
  labs(title=expression(beta[1]))
dat3 <- data.frame(distrib = c(rnorm(n=10000, mean=0, sd=0.05),posterior_approx[,3]),yy = rep(letters[1:2],times = c(10000,m)))
figure3 <- ggplot(dat3,aes(x=distrib)) + 
  #geom_histogram(data=subset(dat3,yy == 'a'),aes(y=..density..),fill = "red", alpha = 0.2,binwidth=1) +
  geom_density(alpha = 0.1, data=subset(dat3,yy == 'a'), col="red",linetype = "dashed") + 
  geom_histogram(data=subset(dat3,yy == 'b'),aes(y=..density..),fill = "blue", alpha = 0.2,binwidth=0.01) +
  geom_density(alpha = 0.1, data=subset(dat3,yy == 'b'), col="blue") + 
  labs(title=expression(beta[2]))
dat4 <- data.frame(distrib = c(rnorm(n=10000, mean=0, sd=0.05),posterior_approx[,4]),yy = rep(letters[1:2],times = c(10000,m)))
figure4 <- ggplot(dat4,aes(x=distrib)) + 
  #geom_histogram(data=subset(dat4,yy == 'a'),aes(y=..density..),fill = "red", alpha = 0.2,binwidth=1) +
  geom_density(alpha = 0.1, data=subset(dat4,yy == 'a'), col="red",linetype = "dashed") + 
  geom_histogram(data=subset(dat4,yy == 'b'),aes(y=..density..),fill = "blue", alpha = 0.2,binwidth=0.01) +
  geom_density(alpha = 0.1, data=subset(dat4,yy == 'b'), col="blue") + 
  labs(title=expression(beta[3])) 
dat5 <- data.frame(distrib = c(runif(n=10000, min=0, max=0.25),posterior_approx[,5]),yy = rep(letters[1:2],times = c(10000,m)))
figure5 <-ggplot(dat5,aes(x=distrib)) + 
  #geom_histogram(data=subset(dat5,yy == 'a'),aes(y=..density..),fill = "red", alpha = 0.2,binwidth=0.1) +
  #geom_density(alpha = 0.1, data=subset(dat5,yy == 'a'), col="red",linetype = "dashed") + 
  geom_segment(aes(x = 0.02, y = 1/(0.25-0.02), xend = 0.25, yend = 1/(0.25-0.02)),linetype = "dashed", colour = "red") + 
  geom_segment(aes(x = 0.25, y = 0, xend = 0.25, yend = 1/(0.25-0.02)),linetype = "dashed", colour = "red") +
  geom_segment(aes(x = 0.02, y = 0, xend = 0.02, yend = 1/(0.25-0.02)),linetype = "dashed", colour = "red") +
  geom_histogram(data=subset(dat5,yy == 'b'),aes(y=..density..),fill = "blue", alpha = 0.2,binwidth=0.005) +
  geom_density(alpha = 0.1, data=subset(dat5,yy == 'b'), col="blue") + 
  labs(title=expression(sigma))
dat6 <- data.frame(distrib = c(runif(n=10000, min=0.1, max=4),posterior_approx[,6]),yy = rep(letters[1:2],times = c(10000,m)))
figure6 <-ggplot(dat6,aes(x=distrib)) + 
  #geom_histogram(data=subset(dat6,yy == 'a'),aes(y=..density..),fill = "red", alpha = 0.2,binwidth=0.05) +
  #geom_density(alpha = 0.1, data=subset(dat6,yy == 'a'), col="red",linetype = "dashed") + 
  geom_segment(aes(x = 0, y = 0.25, xend = 4, yend = 0.25),linetype = "dashed", colour = "red") + 
  geom_segment(aes(x = 4, y = 0, xend = 4, yend = 0.25),linetype = "dashed", colour = "red") +
  geom_segment(aes(x = 0, y = 0, xend = 0, yend = 0.25),linetype = "dashed", colour = "red") +
  geom_histogram(data=subset(dat6,yy == 'b'),aes(y=..density..),fill = "blue", alpha = 0.2,binwidth=0.1) +
  geom_density(alpha = 0.1, data=subset(dat6,yy == 'b'), col="blue") + 
  labs(title=expression(lambda[1]))
dat7 <- data.frame(distrib = c(runif(n=10000, min=0.1, max=4),posterior_approx[,7]),yy = rep(letters[1:2],times = c(10000,m)))
figure7 <-ggplot(dat7,aes(x=distrib)) + 
  #geom_histogram(data=subset(dat7,yy == 'a'),aes(y=..density..),fill = "red", alpha = 0.2,binwidth=0.05) +
  #geom_density(alpha = 0.1, data=subset(dat7,yy == 'a'), col="red",linetype = "dashed") + 
  geom_segment(aes(x = 0, y = 0.25, xend = 4, yend = 0.25),linetype = "dashed", colour = "red") + 
  geom_segment(aes(x = 4, y = 0, xend = 4, yend = 0.25),linetype = "dashed", colour = "red") +
  geom_segment(aes(x = 0, y = 0, xend = 0, yend = 0.25),linetype = "dashed", colour = "red") +
  geom_histogram(data=subset(dat7,yy == 'b'),aes(y=..density..),fill = "blue", alpha = 0.2,binwidth=0.1) +
  geom_density(alpha = 0.1, data=subset(dat7,yy == 'b'), col="blue") + 
  labs(title=expression(lambda[2]))
dat8 <- data.frame(distrib = c(runif(n=10000, min=0.1, max=4),posterior_approx[,8]),yy = rep(letters[1:2],times = c(10000,m)))
figure8 <-ggplot(dat8,aes(x=distrib)) + 
  #geom_histogram(data=subset(dat8,yy == 'a'),aes(y=..density..),fill = "red", alpha = 0.2,binwidth=0.05) +
  #geom_density(alpha = 0.1, data=subset(dat8,yy == 'a'), col="red",linetype = "dashed") + 
  geom_segment(aes(x = 0, y = 0.25, xend = 4, yend = 0.25),linetype = "dashed", colour = "red") + 
  geom_segment(aes(x = 4, y = 0, xend = 4, yend = 0.25),linetype = "dashed", colour = "red") +
  geom_segment(aes(x = 0, y = 0, xend = 0, yend = 0.25),linetype = "dashed", colour = "red") +
  geom_histogram(data=subset(dat8,yy == 'b'),aes(y=..density..),fill = "blue", alpha = 0.2,binwidth=0.1) +
  geom_density(alpha = 0.1, data=subset(dat8,yy == 'b'), col="blue") + 
  labs(title=expression(lambda[3]))
bet<-rbeta(n=10000, shape1=3, shape2=21)
dat9 <- data.frame(distrib = c(log(bet)/(1-bet),posterior_approx[,9]),yy = rep(letters[1:2],times = c(10000,m)))
figure9 <-ggplot(dat9,aes(x=distrib)) + 
  #geom_histogram(data=subset(dat9,yy == 'a'),aes(y=..density..),fill = "red", alpha = 0.2,binwidth=0.2) +
  geom_density(alpha = 0.1, data=subset(dat9,yy == 'a'), col="red",linetype = "dashed") + 
  geom_histogram(data=subset(dat9,yy == 'b'),aes(y=..density..),fill = "blue", alpha = 0.2,binwidth=0.2) +
  geom_density(alpha = 0.1, data=subset(dat9,yy == 'b'), col="blue") + 
  labs(title=expression(p[0]))
dat10 <- data.frame(distrib = c(runif(n=10000, min=-2, max=2),posterior_approx[,10]),yy = rep(letters[1:2],times = c(10000,m)))
figure10 <-ggplot(dat10,aes(x=distrib)) + 
  #geom_histogram(data=subset(dat10,yy == 'a'),aes(y=..density..),fill = "red", alpha = 0.2,binwidth=0.1) +
  #geom_density(alpha = 0.1, data=subset(dat10,yy == 'a'), col="red",linetype = "dashed") + 
  geom_segment(aes(x = -2, y = 0.25, xend = 2, yend = 0.25),linetype = "dashed", colour = "red") + 
  geom_segment(aes(x = 2, y = 0, xend = 2, yend = 0.25),linetype = "dashed", colour = "red") +
  geom_segment(aes(x = -2, y = 0, xend = -2, yend = 0.25),linetype = "dashed", colour = "red") +
  geom_histogram(data=subset(dat10,yy == 'b'),aes(y=..density..),fill = "blue", alpha = 0.2,binwidth=0.2) +
  geom_density(alpha = 0.1, data=subset(dat10,yy == 'b'), col="blue") + 
  labs(title=expression(p[1]))
dat11 <- data.frame(distrib = c(runif(n=10000, min=-2, max=2),posterior_approx[,11]),yy = rep(letters[1:2],times = c(10000,m)))
figure11 <-ggplot(dat11,aes(x=distrib)) + 
  #geom_histogram(data=subset(dat11,yy == 'a'),aes(y=..density..),fill = "red", alpha = 0.2,binwidth=0.1) +
  #geom_density(alpha = 0.1, data=subset(dat11,yy == 'a'), col="red",linetype = "dashed") + 
  geom_segment(aes(x = -2, y = 0.25, xend = 2, yend = 0.25),linetype = "dashed", colour = "red") + 
  geom_segment(aes(x = 2, y = 0, xend = 2, yend = 0.25),linetype = "dashed", colour = "red") +
  geom_segment(aes(x = -2, y = 0, xend = -2, yend = 0.25),linetype = "dashed", colour = "red") +
  geom_histogram(data=subset(dat11,yy == 'b'),aes(y=..density..),fill = "blue", alpha = 0.2,binwidth=0.2) +
  geom_density(alpha = 0.1, data=subset(dat11,yy == 'b'), col="blue") + 
  labs(title=expression(p[2]))
dat12 <- data.frame(distrib = c(runif(n=10000, min=-2, max=2),posterior_approx[,12]),yy = rep(letters[1:2],times = c(10000,m)))
figure12 <-ggplot(dat12,aes(x=distrib)) + 
  #geom_histogram(data=subset(dat12,yy == 'a'),aes(y=..density..),fill = "red", alpha = 0.2,binwidth=0.1) +
  #geom_density(alpha = 0.1, data=subset(dat12,yy == 'a'), col="red",linetype = "dashed") + 
  stat_function(fun = dunif, args = list(min = -2, max = 2), col="red",linetype = "dashed") + 
  geom_segment(aes(x = 2, y = 0, xend = 2, yend = 0.25),linetype = "dashed", colour = "red") +
  geom_segment(aes(x = -2, y = 0, xend = -2, yend = 0.25),linetype = "dashed", colour = "red") +
  geom_histogram(data=subset(dat12,yy == 'b'),aes(y=..density..),fill = "blue", alpha = 0.2,binwidth=0.2) +
  geom_density(alpha = 0.1, data=subset(dat12,yy == 'b'), col="blue") + 
  labs(title=expression(p[3]))


figure <- ggarrange(figure1, figure2, figure3, figure4,figure5, figure6,figure7,figure8,
                    figure9, figure10, figure11, figure12, ncol = 3, nrow = 4,common.legend=T)

figure



#install.packages("HDInterval", dep=T, lib="C:/Program Files/R/R-4.0.5/library"))
library(HDInterval)
hdi(post, credMass = 0.95)

#library(tRophicPosition)
#apply(post,2,getPosteriorMode)

## Modes and Intervals
for (i in 1:12) {
  print(density(post[,i])$x[which.max(density(post[,i])$y)])
  print(round(t(hdi(post[,i], credMass = 0.95)), digits=3))
}



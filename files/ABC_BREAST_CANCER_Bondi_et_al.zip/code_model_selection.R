
#######################################################################
####                    ABC FOR MODEL SELECTION                    ####
#######################################################################

library(abc)

# upload table of simulations - reduced version of 10000 for each model
sum_stat <- read.csv("simulations_abc.csv", header = T)



# observed summaries 
# vector of length 32 containing the observed summary statistics in the real (or mock) data
mock_data<-read.csv("mock_data.csv")
summaries <- function(obs.data) {
  table(obs.data$group)
  # for summary stats (1) and (2)
  prop_diag <- tapply(obs.data$indicator.event, obs.data$group, mean)
  prop_symp_diag <- tapply(obs.data$indicator.symp, obs.data$group, mean, na.rm=T)
  # ASYMPTOMATIC DIAGNOSES (3)
  obs.data$age_asymp_obs <- NA
  obs.data$age_asymp_obs[obs.data$indicator.event==1 & obs.data$indicator.symp==0] <- obs.data$observed[obs.data$indicator.event==1 & obs.data$indicator.symp==0]
  #boxplot(obs.data$age_asymp_obs~obs.data$group)
  median_obs_asymp <- tapply(obs.data$age_asymp_obs, obs.data$group, median, na.rm=T)
  table(!is.na(obs.data$age_asymp_obs), obs.data$group) # numerosity and #diagnoses in each covariate group
  # SYMPTOMATIC DIAGNOSES (4)
  obs.data$age_symp_obs <- NA
  obs.data$age_symp_obs[obs.data$indicator.event==1 & obs.data$indicator.symp==1] <- obs.data$observed[obs.data$indicator.event==1 & obs.data$indicator.symp==1]
  #boxplot(obs.data$age_symp_obs~obs.data$group)
  median_obs_symp <- tapply(obs.data$age_symp_obs, obs.data$group, median, na.rm=T) # observed summaries
  table(!is.na(obs.data$age_symp_obs), obs.data$group) # numerosity and #diagnoses in each covariate group
  #equivalent to  median(obs.data$age_asymp_obs[obs.data$group==1],na.rm=T)
  obs.summaries <- c(prop_diag, prop_symp_diag, median_obs_asymp, median_obs_symp) }###   INSERIRE SUMMARIES DEL MOCK DATASET
obs.summaries <- summaries(mock_data)

###  NAIVE MODEL SELECTION

sum_stat$Model <- as.numeric(sum_stat$Model)
select <- postpr(target=obs.summaries, index=sum_stat[,33], sumstat=sum_stat[,1:32],
                tol=0.02, method="rejection")
summary(select)


###  MODEL SELECTION BASED ON RANDOM-FORESTS

library(abcrf)

set.seed(725)
colnames(sum_stat) <- c("s1","s2","s3","s4","s5","s6","s7","s8","s9","s10","s11","s12",
                             "s13","s14","s15","s16","s17","s18","s19","s20","s21","s22",
                             "s23","s24","s25","s26","s27","s28","s29","s30","s31","s32","Model")
sum_stat$Model <- as.factor(sum_stat$Model)
model_sel <- abcrf(Model~s1 +s2 +s3 +s4 +s5 +s6 +s7 +s8 +s9 +s10 +s11+ s12 +s13 +s14+
                     s15 +s16 +s17 + s18+ s19 +s20 +s21 +s22 +s23 +s24 +s25 +s26 +s27+
                     s28 +s29 +s30 +s31 +s32, data=sum_stat, paral=T, ncores=2)
summary(model_sel)
obs.summaries <- as.data.frame(t(obs.summaries))
colnames(obs.summaries) <- c("s1","s2","s3","s4","s5","s6","s7","s8","s9","s10","s11","s12",
                             "s13","s14","s15","s16","s17","s18","s19","s20","s21","s22",
                             "s23","s24","s25","s26","s27","s28","s29","s30","s31","s32")
pred <- predict(model_sel, training=sum_stat, obs=as.data.frame(obs.summaries))
pred





